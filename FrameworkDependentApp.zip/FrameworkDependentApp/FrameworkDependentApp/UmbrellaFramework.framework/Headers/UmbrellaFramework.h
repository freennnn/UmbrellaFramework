//
//  UmbrellaFramework.h
//  UmbrellaFramework
//
//  Created by Pranevich, Aliaksandr on 9/13/16.
//  Copyright © 2016 Visa. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UmbrellaFramework.
FOUNDATION_EXPORT double UmbrellaFrameworkVersionNumber;

//! Project version string for UmbrellaFramework.
FOUNDATION_EXPORT const unsigned char UmbrellaFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UmbrellaFramework/PublicHeader.h>


